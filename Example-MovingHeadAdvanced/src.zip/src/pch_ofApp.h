#pragma once

#include "ofMain.h"
#include "ofxCvGui.h"
#include "ofxCeres.h"
